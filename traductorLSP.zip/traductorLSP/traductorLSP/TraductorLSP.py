"""
================================================================================
SISTEMA DE RECONOCIMIENTO DE LENGUAJE DE SEÑAS CON TRADUCCIÓN ESPAÑOL-QUECHUA
Versión: 3.0 - Con CRISP-DM y Métricas
Autor: Asistente AI
Descripción: Sistema completo de reconocimiento de señas usando MediaPipe + Transformer
             con traducción automática al quechua y análisis de métricas
================================================================================
"""

import os, cv2, time, glob, random, json, shutil, math
import numpy as np
import mediapipe as mp
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from collections import deque
from datetime import datetime

# =============================================================================
# FASE CRISP-DM 1: COMPRENSIÓN DEL NEGOCIO
# =============================================================================
"""
OBJETIVO DEL PROYECTO:
- Crear un sistema accesible para traducción de lenguaje de señas español-quechua
- Preservar y promover la lengua quechua mediante tecnología
- Facilitar la comunicación para personas con discapacidad auditiva

METAS DE NEGOCIO:
- Reconocimiento en tiempo real con >80% de precisión
- Traducción automática a quechua con diccionario de 200+ palabras
- Interfaz intuitiva y accesible

STAKEHOLDERS:
- Comunidad sorda
- Hablantes de quechua
- Instituciones educativas
- Desarrolladores de tecnología asistiva
"""

# =============================================================================
# CONFIGURACIÓN DEL SISTEMA
# =============================================================================
CONFIG = {
    # Directorios (Gestión de datos)
    'dataset_dir': "dataset",
    'models_dir': "models",
    'metrics_dir': "metrics",
    
    # Grabación (Adquisición de datos)
    'capture_seconds': 8,
    'min_det_conf': 0.5,
    'min_trk_conf': 0.5,
    
    # Entrenamiento (Modelado)
    'batch_size': 16,
    'epochs': 30,
    'learning_rate': 1e-4,
    'weight_decay': 0.01,
    
    # Reconocimiento (Despliegue)
    'umbral_confianza': 0.6,
    'ventana_suavizado': 7,
    'min_frames': 25,
    'frames_confirmacion': 15,
    'max_palabras_frase': 12,
    
    # Transformer (Arquitectura del modelo)
    'd_model': 256,
    'nhead': 8,
    'num_layers': 3,
    'dim_feedforward': 512,
    'dropout': 0.1,
    'max_seq_len': 50,
}

# =============================================================================
# FASE CRISP-DM 2: COMPRENSIÓN DE LOS DATOS
# =============================================================================
"""
FUENTES DE DATOS:
- Landmarks corporales de MediaPipe Holistic (225 características por frame)
- Secuencias temporales de movimientos de señas
- Diccionario español-quechua con categorización semántica

ESTRUCTURA DE DATOS:
- Características: 33 puntos pose + 21 puntos mano izquierda + 21 puntos mano derecha
- Formato: Secuencias numpy (.npy) organizadas por palabra/clase
- Metadatos: Label maps, estadísticas de normalización, métricas
"""

# =============================================================================
# DICCIONARIO ESPAÑOL-QUECHUA (BASE DE CONOCIMIENTO)
# =============================================================================
DICCIONARIO_QUECHUA = {
    # Saludos y Cortesía
    "hola": {"quechua": "Napaykullayki", "categoria": "saludo"},
    "adios": {"quechua": "Tupananchiskama", "categoria": "saludo"},
    "gracias": {"quechua": "Añay", "categoria": "cortesia"},
    "por favor": {"quechua": "Allichu", "categoria": "cortesia"},
    "perdón": {"quechua": "Pampachaykuway", "categoria": "cortesia"},
    "si": {"quechua": "Arí", "categoria": "afirmacion"},
    "no": {"quechua": "Manan", "categoria": "negacion"},
    "buenos dias": {"quechua": "Allin p'unchay", "categoria": "saludo"},
    "buenas tardes": {"quechua": "Allin ch'isi", "categoria": "saludo"},
    "buenas noches": {"quechua": "Allin tuta", "categoria": "saludo"},
    
    # Familia
    "madre": {"quechua": "Mantay", "categoria": "familia"},
    "padre": {"quechua": "Taytay", "categoria": "familia"},
    "hermano": {"quechua": "Wawqi", "categoria": "familia"},
    "hermana": {"quechua": "Pañay", "categoria": "familia"},
    "hijo": {"quechua": "Churi", "categoria": "familia"},
    "hija": {"quechua": "Ususi", "categoria": "familia"},
    "abuelo": {"quechua": "Awichu", "categoria": "familia"},
    "abuela": {"quechua": "Awicha", "categoria": "familia"},
    "tío": {"quechua": "Kaka", "categoria": "familia"},
    "tía": {"quechua": "Kaka", "categoria": "familia"},
    "primo": {"quechua": "Primu", "categoria": "familia"},
    "prima": {"quechua": "Prima", "categoria": "familia"},
    "familia": {"quechua": "Ayllu", "categoria": "familia"},
    
    # Naturaleza y Alimentos
    "agua": {"quechua": "Yaku", "categoria": "naturaleza"},
    "sol": {"quechua": "Inti", "categoria": "naturaleza"},
    "luna": {"quechua": "Killa", "categoria": "naturaleza"},
    "tierra": {"quechua": "Pacha", "categoria": "naturaleza"},
    "comida": {"quechua": "Mikhuna", "categoria": "alimento"},
    "pan": {"quechua": "Tanta", "categoria": "alimento"},
    "maíz": {"quechua": "Sara", "categoria": "alimento"},
    "papa": {"quechua": "Papa", "categoria": "alimento"},
    "arroz": {"quechua": "Arrus", "categoria": "alimento"},
    "fruta": {"quechua": "Ruru", "categoria": "alimento"},
    "carne": {"quechua": "Aycha", "categoria": "alimento"},
    "leche": {"quechua": "Leche", "categoria": "alimento"},
    "queso": {"quechua": "Kisu", "categoria": "alimento"},
    "sal": {"quechua": "Kachi", "categoria": "alimento"},
    "azúcar": {"quechua": "Asukar", "categoria": "alimento"},
    
    # Animales
    "perro": {"quechua": "Allqu", "categoria": "animal"},
    "gato": {"quechua": "Mishi", "categoria": "animal"},
    "pájaro": {"quechua": "Pisqu", "categoria": "animal"},
    "caballo": {"quechua": "Kawallu", "categoria": "animal"},
    "vaca": {"quechua": "Waka", "categoria": "animal"},
    "gallina": {"quechua": "Wallpa", "categoria": "animal"},
    "pez": {"quechua": "Challwa", "categoria": "animal"},
    "oveja": {"quechua": "Uwija", "categoria": "animal"},
    "cerdo": {"quechua": "Khuchi", "categoria": "animal"},
    "llama": {"quechua": "Llama", "categoria": "animal"},
    "alpaca": {"quechua": "Allpaqa", "categoria": "animal"},
    
    # Colores
    "blanco": {"quechua": "Yuraq", "categoria": "color"},
    "negro": {"quechua": "Yana", "categoria": "color"},
    "rojo": {"quechua": "Puka", "categoria": "color"},
    "azul": {"quechua": "Anqas", "categoria": "color"},
    "verde": {"quechua": "Q'omer", "categoria": "color"},
    "amarillo": {"quechua": "Q'ellu", "categoria": "color"},
    "morado": {"quechua": "Kulli", "categoria": "color"},
    "naranja": {"quechua": "Laranja", "categoria": "color"},
    "rosado": {"quechua": "Rosa", "categoria": "color"},
    "gris": {"quechua": "Uqi", "categoria": "color"},
    "marrón": {"quechua": "Allpa", "categoria": "color"},
    
    # Números
    "uno": {"quechua": "Huq", "categoria": "numero"},
    "dos": {"quechua": "Iskay", "categoria": "numero"},
    "tres": {"quechua": "Kinsa", "categoria": "numero"},
    "cuatro": {"quechua": "Tawa", "categoria": "numero"},
    "cinco": {"quechua": "Pesqa", "categoria": "numero"},
    "seis": {"quechua": "Soqta", "categoria": "numero"},
    "siete": {"quechua": "Qanchis", "categoria": "numero"},
    "ocho": {"quechua": "Pusaq", "categoria": "numero"},
    "nueve": {"quechua": "Isqun", "categoria": "numero"},
    "diez": {"quechua": "Chunka", "categoria": "numero"},
    
    # Tiempo y Espacio
    "hoy": {"quechua": "Kunan p'unchaw", "categoria": "tiempo"},
    "mañana": {"quechua": "Paqarin", "categoria": "tiempo"},
    "ayer": {"quechua": "Qayna", "categoria": "tiempo"},
    "día": {"quechua": "P'unchaw", "categoria": "tiempo"},
    "noche": {"quechua": "Tuta", "categoria": "tiempo"},
    "semana": {"quechua": "Simana", "categoria": "tiempo"},
    "mes": {"quechua": "Killa", "categoria": "tiempo"},
    "año": {"quechua": "Wata", "categoria": "tiempo"},
    "casa": {"quechua": "Wasi", "categoria": "lugar"},
    "calle": {"quechua": "Ñan", "categoria": "lugar"},
    "pueblo": {"quechua": "Llajta", "categoria": "lugar"},
    "ciudad": {"quechua": "Hatun llajta", "categoria": "lugar"},
    "país": {"quechua": "Suyu", "categoria": "lugar"},
    "montaña": {"quechua": "Orqo", "categoria": "lugar"},
    "río": {"quechua": "Mayu", "categoria": "lugar"},
    "lago": {"quechua": "Qocha", "categoria": "lugar"},
    
    # Verbos y Acciones
    "comer": {"quechua": "Mihuy", "categoria": "verbo"},
    "beber": {"quechua": "Upyay", "categoria": "verbo"},
    "dormir": {"quechua": "Puñuy", "categoria": "verbo"},
    "caminar": {"quechua": "Puriy", "categoria": "verbo"},
    "trabajar": {"quechua": "Llank'ay", "categoria": "verbo"},
    "amar": {"quechua": "Kuyay", "categoria": "verbo"},
    "hablar": {"quechua": "Rimay", "categoria": "verbo"},
    "escuchar": {"quechua": "Uyariy", "categoria": "verbo"},
    "ver": {"quechua": "Rikuy", "categoria": "verbo"},
    "oir": {"quechua": "Uyariy", "categoria": "verbo"},
    "estudiar": {"quechua": "Yachay", "categoria": "verbo"},
    "enseñar": {"quechua": "Yachachiy", "categoria": "verbo"},
    "aprender": {"quechua": "Yachakuy", "categoria": "verbo"},
    "comprar": {"quechua": "Rantiy", "categoria": "verbo"},
    "vender": {"quechua": "Rantikuy", "categoria": "verbo"},
    "cantar": {"quechua": "Takiy", "categoria": "verbo"},
    "bailar": {"quechua": "Tusuy", "categoria": "verbo"},
    "jugar": {"quechua": "Pukllay", "categoria": "verbo"},
    "leer": {"quechua": "Ñawiriy", "categoria": "verbo"},
    "escribir": {"quechua": "Qillqay", "categoria": "verbo"},
    
    # Países y Lugares
    "peru": {"quechua": "Piruw", "categoria": "lugar"},
    "cuzco": {"quechua": "Qosqo", "categoria": "lugar"},
    "andes": {"quechua": "Antis", "categoria": "lugar"},
    "américa": {"quechua": "Abya Yala", "categoria": "lugar"},
    "mundo": {"quechua": "Pacha", "categoria": "lugar"},
    
    # Pronombres y Personas
    "yo": {"quechua": "Noqa", "categoria": "pronombre"},
    "tu": {"quechua": "Qan", "categoria": "pronombre"},
    "el": {"quechua": "Pay", "categoria": "pronombre"},
    "ella": {"quechua": "Pay", "categoria": "pronombre"},
    "nosotros": {"quechua": "Ñuqanchik", "categoria": "pronombre"},
    "ustedes": {"quechua": "Qankuna", "categoria": "pronombre"},
    "ellos": {"quechua": "Paykuna", "categoria": "pronombre"},
    "persona": {"quechua": "Runa", "categoria": "persona"},
    "hombre": {"quechua": "Qhari", "categoria": "persona"},
    "mujer": {"quechua": "Warmi", "categoria": "persona"},
    "niño": {"quechua": "Wawa", "categoria": "persona"},
    "niña": {"quechua": "Wawa", "categoria": "persona"},
    "amigo": {"quechua": "Masi", "categoria": "persona"},
    
    # Sentimientos
    "feliz": {"quechua": "Kusisqa", "categoria": "sentimiento"},
    "triste": {"quechua": "Llakisqa", "categoria": "sentimiento"},
    "amor": {"quechua": "Munay", "categoria": "sentimiento"},
    "corazón": {"quechua": "Sonqo", "categoria": "sentimiento"},
    "alegría": {"quechua": "Kusi", "categoria": "sentimiento"},
    "enojo": {"quechua": "Phiña", "categoria": "sentimiento"},
    "miedo": {"quechua": "Manchay", "categoria": "sentimiento"},
    "paz": {"quechua": "Thak", "categoria": "sentimiento"},
    
    # Partes del Cuerpo
    "mano": {"quechua": "Maki", "categoria": "cuerpo"},
    "cabeza": {"quechua": "Uma", "categoria": "cuerpo"},
    "ojo": {"quechua": "Ñawi", "categoria": "cuerpo"},
    "boca": {"quechua": "Simi", "categoria": "cuerpo"},
    "nariz": {"quechua": "Sinqa", "categoria": "cuerpo"},
    "oreja": {"quechua": "Ninri", "categoria": "cuerpo"},
    "pie": {"quechua": "Chaki", "categoria": "cuerpo"},
    "brazo": {"quechua": "K'epi", "categoria": "cuerpo"},
    "pierna": {"quechua": "Chanka", "categoria": "cuerpo"},
    "cara": {"quechua": "Uya", "categoria": "cuerpo"},
    "cabello": {"quechua": "Chukcha", "categoria": "cuerpo"},
    "diente": {"quechua": "Kiru", "categoria": "cuerpo"},
    "lengua": {"quechua": "Qallu", "categoria": "cuerpo"},
    
    # Misceláneo
    "amigo": {"quechua": "Masi", "categoria": "social"},
    "gente": {"quechua": "Runa", "categoria": "social"},
    "fiesta": {"quechua": "Raymi", "categoria": "cultura"},
    "música": {"quechua": "Takiy", "categoria": "cultura"},
    "baile": {"quechua": "Tusuy", "categoria": "cultura"},
    "libro": {"quechua": "Liwru", "categoria": "objeto"},
    "escuela": {"quechua": "Yachay wasi", "categoria": "educacion"},
    "maestro": {"quechua": "Yachachiq", "categoria": "educacion"},
    "estudiante": {"quechua": "Yachakuq", "categoria": "educacion"},
    "conocimiento": {"quechua": "Yachay", "categoria": "educacion"},
    "trabajo": {"quechua": "Llank'ay", "categoria": "trabajo"},
    "dinero": {"quechua": "Qullqi", "categoria": "economia"},
    "tiempo": {"quechua": "Pacha", "categoria": "tiempo"},
    "vida": {"quechua": "Kawsay", "categoria": "filosofia"},
    "muerte": {"quechua": "Wañuy", "categoria": "filosofia"},
    "dios": {"quechua": "Diyus", "categoria": "religion"},
    "espíritu": {"quechua": "Espiritu", "categoria": "religion"},
    "naturaleza": {"quechua": "Pacha", "categoria": "naturaleza"},
    "universo": {"quechua": "Pacha", "categoria": "cosmos"},

    #Profesiones
    "profesor": {"quechua": "yachacheq","categoria": "profesion"},

}


# Configurar semillas para reproducibilidad
random.seed(42)
np.random.seed(42)
torch.manual_seed(42)

# =============================================================================
# FASE CRISP-DM 3: PREPARACIÓN DE LOS DATOS
# =============================================================================
"""
PROCESO DE PREPARACIÓN:
1. Extracción de landmarks con MediaPipe Holistic
2. Normalización consistente de características
3. Organización en secuencias temporales
4. Creación de datasets balanceados
5. Preprocesamiento para el modelo Transformer
"""

class TraductorQuechua:
    """Sistema de traducción español-quechua basado en diccionario"""
    
    def __init__(self):
        # Inicializar diccionario y reglas gramaticales
        self.diccionario = DICCIONARIO_QUECHUA
        self.reglas_verbos = self._inicializar_reglas_verbos()
        print(f"✅ Traductor cargado: {len(self.diccionario)} palabras")
    
    def _inicializar_reglas_verbos(self):
        """Reglas básicas para conjugación de verbos en quechua"""
        return {
            "ar": {"yo": "ni", "tú": "nki", "él": "n", "nosotros": "nchik", "ustedes": "nkichik"},
            "er": {"yo": "ni", "tú": "nki", "él": "n", "nosotros": "nchik", "ustedes": "nkichik"},
            "ir": {"yo": "ni", "tú": "nki", "él": "n", "nosotros": "nchik", "ustedes": "nkichik"}
        }
    
    def traducir_palabra(self, palabra):
        """Traduce una palabra individual del español al quechua"""
        palabra_lower = palabra.lower().strip()
        
        # Búsqueda directa en diccionario
        if palabra_lower in self.diccionario:
            return self.diccionario[palabra_lower]["quechua"]
        
        # Búsqueda de variaciones (plurales, género)
        traduccion = self._buscar_variaciones(palabra_lower)
        if traduccion:
            return traduccion
        
        # Palabra no encontrada
        return f"[{palabra}]"
    
    def _buscar_variaciones(self, palabra):
        """Busca variaciones morfológicas de la palabra"""
        # Manejo de plurales (remover 's' final)
        if palabra.endswith('s') and len(palabra) > 1:
            singular = palabra[:-1]
            if singular in self.diccionario:
                return self.diccionario[singular]["quechua"]
        
        # Manejo de género (intercambiar a/o)
        if palabra.endswith('a'):
            masculino = palabra[:-1] + 'o'
            if masculino in self.diccionario:
                return self.diccionario[masculino]["quechua"]
        
        if palabra.endswith('o'):
            femenino = palabra[:-1] + 'a'
            if femenino in self.diccionario:
                return self.diccionario[femenino]["quechua"]
        
        return None
    
    def traducir_frase_completa(self, frase):
        """Traduce frase completa aplicando reglas gramaticales básicas"""
        if not frase or frase == "[Frase vacía]":
            return "[Frase vacía]"
        
        # Traducción palabra por palabra
        palabras = frase.split()
        palabras_traducidas = []
        
        for palabra in palabras:
            palabras_traducidas.append(self.traducir_palabra(palabra))
        
        # Aplicar orden SOV (Sujeto-Objeto-Verbo) del quechua
        frase_traducida = " ".join(palabras_traducidas)
        frase_traducida = self._ajustar_orden_oracion(frase_traducida, palabras)
        
        return frase_traducida
    
    def _ajustar_orden_oracion(self, frase_traducida, palabras_originales):
        """Ajusta el orden de la oración según sintaxis quechua"""
        palabras_trad = frase_traducida.split()
        
        # Identificar verbos en español
        verbos_indices = []
        for i, palabra in enumerate(palabras_originales):
            if any(palabra.endswith(terminacion) for terminacion in ['ar', 'er', 'ir', 'y']):
                verbos_indices.append(i)
        
        # Mover verbos al final (orden SOV)
        if verbos_indices and len(palabras_trad) > 1:
            for idx in sorted(verbos_indices, reverse=True):
                if idx < len(palabras_trad) - 1:
                    verbo = palabras_trad.pop(idx)
                    palabras_trad.append(verbo)
        
        return " ".join(palabras_trad)

# =============================================================================
# EXTRACCIÓN DE CARACTERÍSTICAS CON MEDIAPIPE
# =============================================================================
# Inicializar MediaPipe Holistic para detección de landmarks
mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils

def get_holistic():
    """Configura y retorna el modelo MediaPipe Holistic"""
    return mp_holistic.Holistic(
        min_detection_confidence=CONFIG['min_det_conf'],
        min_tracking_confidence=CONFIG['min_trk_conf']
    )

def extract_features(results):
    """
    Extrae 225 características de landmarks corporales:
    - 33 puntos de pose (99 características: x,y,z)
    - 21 puntos mano izquierda (63 características)
    - 21 puntos mano derecha (63 características)
    """
    feats = []
    
    # Landmarks de pose (33 puntos)
    if results.pose_landmarks:
        for lm in results.pose_landmarks.landmark:
            feats.extend([lm.x, lm.y, lm.z])
    else:
        feats.extend([0.0, 0.0, 0.0] * 33)

    # Landmarks mano izquierda (21 puntos)
    if results.left_hand_landmarks:
        for lm in results.left_hand_landmarks.landmark:
            feats.extend([lm.x, lm.y, lm.z])
    else:
        feats.extend([0.0, 0.0, 0.0] * 21)

    # Landmarks mano derecha (21 puntos)
    if results.right_hand_landmarks:
        for lm in results.right_hand_landmarks.landmark:
            feats.extend([lm.x, lm.y, lm.z])
    else:
        feats.extend([0.0, 0.0, 0.0] * 21)

    # Validar y ajustar dimensión (225 características)
    expected_dim = 33*3 + 21*3 + 21*3
    if len(feats) != expected_dim:
        if len(feats) < expected_dim:
            feats.extend([0.0] * (expected_dim - len(feats)))
        else:
            feats = feats[:expected_dim]
    
    return np.array(feats, dtype=np.float32)

# Dimensión fija de características
FEATURE_DIM = 33*3 + 21*3 + 21*3  # 225 características

# =============================================================================
# NORMALIZACIÓN DE CARACTERÍSTICAS
# =============================================================================
class NormalizadorConsistente:
    """
    Sistema de normalización consistente entre entrenamiento e inferencia
    Garantiza que las características tengan misma distribución en ambos modos
    """
    
    def __init__(self, method='zscore'):
        self.method = method
        self.stats = {}  # Almacena estadísticas para normalización
        
    def calcular_estadisticas(self, sequences):
        """Calcula estadísticas globales del dataset completo"""
        if not sequences:
            return
            
        # Concatenar todas las secuencias para estadísticas globales
        all_data = np.concatenate(sequences, axis=0)
        self.stats = {
            'mean': all_data.mean(axis=0),
            'std': all_data.std(axis=0) + 1e-8,  # Evitar división por cero
            'min': all_data.min(axis=0),
            'max': all_data.max(axis=0)
        }
    
    def normalizar_secuencia(self, secuencia):
        """Aplica normalización consistente a una secuencia"""
        # Normalización Z-score (preferida)
        if self.method == 'zscore' and 'mean' in self.stats:
            return (secuencia - self.stats['mean']) / self.stats['std']
        
        # Normalización Min-Max
        elif self.method == 'minmax' and 'min' in self.stats:
            return (secuencia - self.stats['min']) / (self.stats['max'] - self.stats['min'] + 1e-8)
        
        # Fallback: normalización por secuencia individual
        else:
            if secuencia.shape[0] > 1:
                mean = secuencia.mean(axis=0, keepdims=True)
                std = secuencia.std(axis=0, keepdims=True) + 1e-8
                return (secuencia - mean) / std
            return secuencia

# =============================================================================
# FASE CRISP-DM 4: MODELADO
# =============================================================================
"""
ARQUITECTURA DEL MODELO:
- Transformer especializado para secuencias temporales
- Positional Encoding para información de timing
- Mecanismo de atención temporal
- Clasificación con capas fully connected

VENTAJAS:
- Captura dependencias temporales largas
- Atención a frames más importantes
- Robustez a variaciones en velocidad de señas
"""

class SignLanguageTransformer(nn.Module):
    """Transformer especializado para reconocimiento de lenguaje de señas"""
    
    def __init__(self, feature_dim, num_classes, max_seq_len=50):
        super().__init__()
        
        self.d_model = CONFIG['d_model']
        self.max_seq_len = max_seq_len
        
        # 1. PROYECCIÓN DE CARACTERÍSTICAS (225 -> d_model)
        self.feature_projection = nn.Linear(feature_dim, self.d_model)
        
        # 2. POSITIONAL ENCODING (Esencial para información temporal)
        self.pos_encoding = nn.Parameter(torch.zeros(1, max_seq_len, self.d_model))
        
        # 3. ENCODER TRANSFORMER (Núcleo del modelo)
        encoder_layers = nn.TransformerEncoderLayer(
            d_model=self.d_model,
            nhead=CONFIG['nhead'],           # 8 cabezas de atención
            dim_feedforward=CONFIG['dim_feedforward'],  # 512 dimensiones FFN
            dropout=CONFIG['dropout'],       # 0.1 dropout para regularización
            batch_first=True,                # Formato [batch, seq, features]
            activation='gelu'                # GELU para mejor rendimiento
        )
        self.transformer_encoder = nn.TransformerEncoder(
            encoder_layers, 
            num_layers=CONFIG['num_layers']  # 3 capas transformer
        )
        
        # 4. ATENCIÓN TEMPORAL (Ponderación de frames importantes)
        self.temporal_attention = nn.Sequential(
            nn.Linear(self.d_model, self.d_model // 2),
            nn.Tanh(),
            nn.Linear(self.d_model // 2, 1),  # Score de importancia por frame
            nn.Dropout(CONFIG['dropout'])
        )
        
        # 5. CLASIFICADOR FINAL
        self.classifier = nn.Sequential(
            nn.LayerNorm(self.d_model),      # Normalización
            nn.Linear(self.d_model, CONFIG['dim_feedforward'] // 2),
            nn.GELU(),                       # Activación
            nn.Dropout(CONFIG['dropout']),   # Regularización
            nn.Linear(CONFIG['dim_feedforward'] // 2, num_classes)  # Salida final
        )
        
        self._init_weights()  # Inicialización de parámetros
    
    def _init_weights(self):
        """Inicialización Xavier para mejor convergencia"""
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
        # Inicialización especial para positional encoding
        nn.init.normal_(self.pos_encoding, std=0.02)
    
    def forward(self, x, lengths=None):
        """
        Forward pass del modelo
        x: [batch_size, seq_len, feature_dim]
        lengths: longitudes reales de secuencias (para padding)
        """
        batch_size, seq_len, _ = x.shape
        
        # 1. Proyección de características y escalado
        x = self.feature_projection(x)  # [batch, seq_len, d_model]
        x = x * math.sqrt(self.d_model)  # Escalar por dimensión
        
        # 2. Añadir positional encoding
        if seq_len <= self.max_seq_len:
            pos_embed = self.pos_encoding[:, :seq_len, :]
        else:
            # Interpolación para secuencias más largas
            pos_embed = F.interpolate(
                self.pos_encoding.transpose(1, 2), 
                size=seq_len, 
                mode='linear'
            ).transpose(1, 2)
        
        x = x + pos_embed  # Añadir información posicional
        
        # 3. Máscara de atención (para padding)
        if lengths is not None:
            max_len = x.size(1)
            mask = torch.arange(max_len, device=x.device).expand(len(lengths), max_len) >= lengths.unsqueeze(1)
            mask = mask.to(x.device)
        else:
            mask = None
        
        # 4. Procesamiento con Transformer
        x = self.transformer_encoder(x, src_key_padding_mask=mask)  # [batch, seq_len, d_model]
        
        # 5. Atención temporal (en lugar de mean pooling simple)
        attention_weights = self.temporal_attention(x)  # [batch, seq_len, 1]
        attention_weights = F.softmax(attention_weights, dim=1)  # Normalizar a distribución
        weighted_embedding = torch.sum(x * attention_weights, dim=1)  # [batch, d_model]
        
        # 6. Clasificación final
        return self.classifier(weighted_embedding)

# =============================================================================
# CONSTRUCTOR DE FRASES BILINGÜES
# =============================================================================
class FraseBuilderBilingue:
    """
    Sistema inteligente para construcción de frases con:
    - Detección de señas en tiempo real
    - Confirmación por múltiples frames
    - Traducción automática español-quechua
    - Prevención de duplicados
    """
    
    def __init__(self, traductor):
        self.frase_espanol = []           # Palabras en español confirmadas
        self.frase_quechua = ""           # Frase traducida completa
        self.palabra_actual = None        # Palabra siendo detectada
        self.contador = 0                 # Frames de confirmación
        self.confianza_acumulada = 0.0    # Confianza acumulada
        self.traductor = traductor        # Instancia del traductor
        
    def procesar_prediccion(self, palabra, confianza):
        """Procesa nueva predicción con lógica de confirmación"""
        
        # Filtrar predicciones de baja confianza
        if confianza < CONFIG['umbral_confianza'] or palabra == "...":
            return "⏳ Esperando seña..."
        
        # Misma palabra detectada (acumular confirmación)
        if palabra == self.palabra_actual:
            self.contador += 1
            self.confianza_acumulada += confianza
            
            conf_promedio = self.confianza_acumulada / self.contador
            
            # Verificar si confirmar palabra
            if self.contador >= CONFIG['frames_confirmacion'] and conf_promedio > CONFIG['umbral_confianza']:
                return self._confirmar_palabra(palabra)
            else:
                # Mostrar progreso de detección
                progreso = (self.contador / CONFIG['frames_confirmacion']) * 100
                traduccion = self.traductor.traducir_palabra(palabra)
                return f"📊 Detectando: {palabra} → {traduccion} ({progreso:.0f}%)"
        
        # Nueva palabra detectada (reiniciar contadores)
        else:
            self.palabra_actual = palabra
            self.contador = 1
            self.confianza_acumulada = confianza
            traduccion = self.traductor.traducir_palabra(palabra)
            return f"🔄 Nueva: {palabra} → {traduccion}"
    
    def _confirmar_palabra(self, palabra):
        """Confirma y agrega palabra a la frase bilingüe"""
        # Evitar duplicados consecutivos
        if self.frase_espanol and self.frase_espanol[-1] == palabra:
            self._resetear_estado()
            return "⚠️  Palabra duplicada (ignorada)"
        
        # Verificar límite de palabras por frase
        if len(self.frase_espanol) >= CONFIG['max_palabras_frase']:
            self._resetear_estado()
            return "📝 Límite de palabras alcanzado"
        
        # Agregar palabra y actualizar traducción
        self.frase_espanol.append(palabra)
        frase_actual = " ".join(self.frase_espanol)
        self.frase_quechua = self.traductor.traducir_frase_completa(frase_actual)
        
        self._resetear_estado()
        traduccion_palabra = self.traductor.traducir_palabra(palabra)
        return f"✅ '{palabra}' → '{traduccion_palabra}' agregada"
    
    def _resetear_estado(self):
        """Resetea el estado de detección actual"""
        self.palabra_actual = None
        self.contador = 0
        self.confianza_acumulada = 0.0
    
    def obtener_frase_bilingue(self):
        """Devuelve la frase completa en español y quechua"""
        frase_es = " ".join(self.frase_espanol) if self.frase_espanol else "[Frase vacía]"
        
        # Traducción completa de la frase actual
        if self.frase_espanol:
            frase_qu = self.traductor.traducir_frase_completa(frase_es)
        else:
            frase_qu = "[Frase vacía]"
            
        return frase_es, frase_qu
    
    def reiniciar(self):
        """Reinicia completamente el constructor de frases"""
        self.frase_espanol = []
        self.frase_quechua = ""
        self._resetear_estado()

# =============================================================================
# INTERFAZ VISUAL MEJORADA
# =============================================================================
def dibujar_interfaz_bilingue(frame, frase_espanol, frase_quechua, palabra_actual, confianza, mensaje_estado):
    """
    Dibuja interfaz visual bilingüe en el frame de video:
    - Frase en español y quechua
    - Palabra actual detectada
    - Barra de progreso/estado
    - Comandos de usuario
    """
    
    # Fondo semitransparente para texto
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (frame.shape[1], 140), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
    
    # Frase en español (amarillo)
    cv2.putText(frame, f"🗣️  ESPAÑOL: {frase_espanol}", 
               (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
    
    # Frase en quechua (cyan)
    cv2.putText(frame, f"🌄  QUECHUA: {frase_quechua}", 
               (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
    
    # Detección actual (color según confianza)
    color = (0, 255, 0) if confianza > 0.7 else (0, 200, 255) if confianza > 0.5 else (0, 100, 255)
    cv2.putText(frame, f"👆 {palabra_actual} ({confianza:.1%})",
               (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
    
    # Mensaje de estado
    cv2.putText(frame, f"📊 {mensaje_estado}",
               (10, 105), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    # Comandos de usuario
    cv2.putText(frame, "⌨️  'q'=Salir, 'r'=Reiniciar frase, 'd'=Ver diccionario", 
               (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

# =============================================================================
# GESTIÓN DE DATASET Y METADATOS
# =============================================================================
def list_all_files():
    """Lista todos los archivos .npy del dataset organizados por clase"""
    return sorted(glob.glob(os.path.join(CONFIG['dataset_dir'], "*", "*.npy")))

def get_available_classes():
    """Obtiene las clases disponibles basadas en archivos existentes"""
    files = list_all_files()
    classes = set()
    
    for file_path in files:
        # Extraer nombre de clase del path del archivo
        class_name = os.path.basename(os.path.dirname(file_path))
        if class_name and class_name != CONFIG['dataset_dir']:
            classes.add(class_name)
    
    return sorted(list(classes))

def build_label_map():
    """Construye mapeo de etiquetas basado en dataset existente"""
    label_map_path = os.path.join(CONFIG['models_dir'], "label_map.json")
    
    # Cargar mapa existente si está actualizado
    if os.path.exists(label_map_path):
        with open(label_map_path, "r", encoding="utf-8") as f:
            existing_map = json.load(f)
            available_classes = get_available_classes()
            if available_classes and set(existing_map.keys()) == set(available_classes):
                return existing_map
    
    # Crear nuevo mapa de etiquetas
    available_classes = get_available_classes()
    if not available_classes:
        return {}
    
    label_map = {class_name: idx for idx, class_name in enumerate(available_classes)}
    
    # Guardar mapa de etiquetas
    os.makedirs(CONFIG['models_dir'], exist_ok=True)
    with open(label_map_path, "w", encoding="utf-8") as f:
        json.dump(label_map, f, ensure_ascii=False, indent=2)
    
    return label_map

# =============================================================================
# DATASET Y DATA LOADER PARA PYTORCH
# =============================================================================
class SignDataset(Dataset):
    """Dataset personalizado para secuencias de lenguaje de señas"""
    
    def __init__(self, files, label_map, normalizador):
        self.files = files
        self.label_map = label_map
        self.normalizador = normalizador

    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        # Cargar secuencia y etiqueta
        path = self.files[idx]
        seq = np.load(path)
        palabra = os.path.basename(os.path.dirname(path))
        label = self.label_map[palabra]
        
        # Aplicar normalización consistente
        seq = self.normalizador.normalizar_secuencia(seq)
        
        return torch.tensor(seq, dtype=torch.float32), torch.tensor(label, dtype=torch.long)

def collate_fn(batch):
    """Función para agrupar secuencias de diferente longitud"""
    sequences, labels = zip(*batch)
    lengths = [s.shape[0] for s in sequences]
    T_max = max(lengths)
    
    # Crear tensor padding para batch
    src = torch.zeros((len(sequences), T_max, FEATURE_DIM), dtype=torch.float32)
    for i, s in enumerate(sequences):
        src[i, :s.shape[0], :] = s
    
    return src, torch.tensor(lengths, dtype=torch.long), torch.stack(labels)

# =============================================================================
# MANEJO SEGURO DE ARCHIVOS PYTORCH
# =============================================================================
def safe_torch_load(filepath):
    """Carga segura compatible con PyTorch 2.6+"""
    try:
        # Intentar carga segura (PyTorch 2.6+)
        return torch.load(filepath, weights_only=True)
    except:
        try:
            # Fallback a carga tradicional
            return torch.load(filepath, weights_only=False)
        except:
            print(f"⚠️  No se pudo cargar el archivo: {filepath}")
            return None

def safe_torch_save(obj, filepath):
    """Guardado seguro de modelos PyTorch"""
    try:
        torch.save(obj, filepath)
        return True
    except Exception as e:
        print(f"❌ Error guardando archivo {filepath}: {e}")
        return False

# =============================================================================
# FASE CRISP-DM 5: EVALUACIÓN - SISTEMA DE MÉTRICAS
# =============================================================================
"""
MÉTRICAS IMPLEMENTADAS:
- Precisión de clasificación (train/val)
- Pérdida durante entrenamiento
- Distribución del dataset
- Estadísticas de uso
- Rendimiento en tiempo real
"""

class MetricasSistema:
    """Sistema completo de métricas y evaluación del modelo"""
    
    def __init__(self):
        self.metricas_path = os.path.join(CONFIG['metrics_dir'], "metricas.json")
        os.makedirs(CONFIG['metrics_dir'], exist_ok=True)
        self.cargar_metricas()
    
    def cargar_metricas(self):
        """Carga métricas existentes o inicializa nuevas"""
        if os.path.exists(self.metricas_path):
            with open(self.metricas_path, 'r', encoding='utf-8') as f:
                self.metricas = json.load(f)
        else:
            self.metricas = {
                "entrenamiento": {
                    "mejor_precision": 0.0,
                    "ultima_precision": 0.0,
                    "total_entrenamientos": 0,
                    "historial_epocas": []
                },
                "dataset": {
                    "total_clases": 0,
                    "total_muestras": 0,
                    "distribucion_clases": {},
                    "ultima_actualizacion": ""
                },
                "tiempo_real": {
                    "sesiones_totales": 0,
                    "promedio_confianza": 0.0,
                    "frases_traducidas": 0,
                    "errores_deteccion": 0
                },
                "rendimiento": {
                    "fps_promedio": 0.0,
                    "latencia_inferencia": 0.0,
                    "uso_memoria": 0.0
                }
            }
    
    def guardar_metricas(self):
        """Guarda métricas actualizadas a disco"""
        with open(self.metricas_path, 'w', encoding='utf-8') as f:
            json.dump(self.metricas, f, ensure_ascii=False, indent=2)
    
    def actualizar_metricas_entrenamiento(self, precision_val, historial_epocas):
        """Actualiza métricas después del entrenamiento"""
        self.metricas["entrenamiento"]["ultima_precision"] = precision_val
        self.metricas["entrenamiento"]["total_entrenamientos"] += 1
        self.metricas["entrenamiento"]["historial_epocas"] = historial_epocas[-10:]  # Últimas 10 épocas
        
        if precision_val > self.metricas["entrenamiento"]["mejor_precision"]:
            self.metricas["entrenamiento"]["mejor_precision"] = precision_val
        
        self.actualizar_metricas_dataset()
        self.guardar_metricas()
    
    def actualizar_metricas_dataset(self):
        """Actualiza estadísticas del dataset"""
        available_classes = get_available_classes()
        files = list_all_files()
        
        self.metricas["dataset"]["total_clases"] = len(available_classes)
        self.metricas["dataset"]["total_muestras"] = len(files)
        self.metricas["dataset"]["ultima_actualizacion"] = datetime.now().isoformat()
        
        # Distribución por clase
        distribucion = {}
        for clase in available_classes:
            count = len(glob.glob(os.path.join(CONFIG['dataset_dir'], clase, "*.npy")))
            distribucion[clase] = count
        self.metricas["dataset"]["distribucion_clases"] = distribucion
    
    def actualizar_metricas_tiempo_real(self, confianza_promedio, frases_traducidas=0):
        """Actualiza métricas de uso en tiempo real"""
        self.metricas["tiempo_real"]["sesiones_totales"] += 1
        self.metricas["tiempo_real"]["promedio_confianza"] = (
            self.metricas["tiempo_real"]["promedio_confianza"] + confianza_promedio
        ) / 2
        self.metricas["tiempo_real"]["frases_traducidas"] += frases_traducidas
        self.guardar_metricas()
    
    def mostrar_metricas_completas(self):
        """Muestra reporte completo de métricas del sistema"""
        print("\n" + "="*70)
        print("📊 MÉTRICAS COMPLETAS DEL SISTEMA LSP")
        print("="*70)
        
        # Métricas de entrenamiento
        print("\n🎯 MÉTRICAS DE ENTRENAMIENTO:")
        print(f"   • Mejor precisión: {self.metricas['entrenamiento']['mejor_precision']:.3f}")
        print(f"   • Última precisión: {self.metricas['entrenamiento']['ultima_precision']:.3f}")
        print(f"   • Total entrenamientos: {self.metricas['entrenamiento']['total_entrenamientos']}")
        
        # Métricas del dataset
        print("\n📁 MÉTRICAS DEL DATASET:")
        print(f"   • Clases disponibles: {self.metricas['dataset']['total_clases']}")
        print(f"   • Muestras totales: {self.metricas['dataset']['total_muestras']}")
        print(f"   • Última actualización: {self.metricas['dataset']['ultima_actualizacion'][:19]}")
        
        # Distribución de clases
        if self.metricas['dataset']['distribucion_clases']:
            print("\n   Distribución por clase:")
            for clase, count in list(self.metricas['dataset']['distribucion_clases'].items())[:5]:
                print(f"     - {clase}: {count} muestras")
            if len(self.metricas['dataset']['distribucion_clases']) > 5:
                print(f"     ... y {len(self.metricas['dataset']['distribucion_clases']) - 5} clases más")
        
        # Métricas de tiempo real
        print("\n🔄 MÉTRICAS DE TIEMPO REAL:")
        print(f"   • Sesiones de uso: {self.metricas['tiempo_real']['sesiones_totales']}")
        print(f"   • Confianza promedio: {self.metricas['tiempo_real']['promedio_confianza']:.3f}")
        print(f"   • Frases traducidas: {self.metricas['tiempo_real']['frases_traducidas']}")
        
        # Métricas del diccionario
        print(f"\n📖 MÉTRICAS DEL TRADUCTOR:")
        print(f"   • Palabras en diccionario: {len(DICCIONARIO_QUECHUA)}")
        
        # Recomendaciones basadas en métricas
        print("\n💡 RECOMENDACIONES:")
        if self.metricas['dataset']['total_muestras'] < 50:
            print("   ⚠️  Dataset pequeño. Graba más señas para mejorar precisión.")
        if self.metricas['entrenamiento']['mejor_precision'] < 0.7:
            print("   ⚠️  Precisión baja. Considera reentrenar con más datos.")
        if self.metricas['dataset']['total_clases'] < 5:
            print("   ⚠️  Pocas clases. Agrega más diversidad de señas.")
        
        print("="*70)

# =============================================================================
# ENTRENAMIENTO DEL MODELO TRANSFORMER
# =============================================================================
def entrenar_modelo():
    """Sistema completo de entrenamiento del modelo Transformer"""
    # FASE CRISP-DM 4: MODELADO (Implementación)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🖥️  Usando dispositivo: {device}")
    
    # Preparar datos
    label_map = build_label_map()
    available_classes = get_available_classes()
    
    # Validaciones iniciales
    if len(available_classes) < 2:
        print("❌ Se necesitan al menos 2 clases para entrenar")
        print(f"💡 Clases actuales: {available_classes}")
        print("   Graba al menos 2 señas diferentes primero")
        return
    
    files = list_all_files()
    if not files:
        print("❌ No hay muestras para entrenar")
        return
    
    print(f"📊 Dataset: {len(label_map)} clases, {len(files)} muestras")
    print(f"🔤 Clases: {', '.join(available_classes)}")
    
    # Inicializar sistema de métricas
    metricas = MetricasSistema()
    
    # Configurar normalizador y calcular estadísticas
    normalizador = NormalizadorConsistente(method='zscore')
    
    print("📈 Calculando estadísticas para normalización...")
    all_sequences = []
    for file in files:
        seq = np.load(file)
        all_sequences.append(seq)
    normalizador.calcular_estadisticas(all_sequences)
    
    # División train/validation (80/20)
    random.shuffle(files)
    split_idx = int(0.8 * len(files))
    train_files, val_files = files[:split_idx], files[split_idx:]
    
    # Crear datasets y data loaders
    train_ds = SignDataset(train_files, label_map, normalizador)
    val_ds = SignDataset(val_files, label_map, normalizador)
    
    train_dl = DataLoader(train_ds, batch_size=min(CONFIG['batch_size'], len(train_files)), 
                         shuffle=True, collate_fn=collate_fn)
    val_dl = DataLoader(val_ds, batch_size=min(CONFIG['batch_size'], len(val_files)), 
                       shuffle=False, collate_fn=collate_fn)
    
    # Inicializar modelo Transformer
    model = SignLanguageTransformer(FEATURE_DIM, len(label_map)).to(device)
    
    # Configurar optimizador y scheduler
    optimizer = torch.optim.AdamW(
        model.parameters(), 
        lr=CONFIG['learning_rate'],
        weight_decay=CONFIG['weight_decay']
    )
    
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, 
        T_max=CONFIG['epochs']
    )
    
    criterion = nn.CrossEntropyLoss()
    
    print(f"🚀 Entrenando Transformer por {CONFIG['epochs']} épocas...")
    print(f"📐 Arquitectura: d_model={CONFIG['d_model']}, heads={CONFIG['nhead']}, layers={CONFIG['num_layers']}")
    
    # Variables para seguimiento del entrenamiento
    best_val_acc = 0.0
    historial_epocas = []
    
    # Bucle principal de entrenamiento
    for epoch in range(1, CONFIG['epochs'] + 1):
        # Fase de entrenamiento
        model.train()
        total_loss, total_correct = 0.0, 0
        total_samples = 0
        
        for src, lengths, labels in train_dl:
            src, labels = src.to(device), labels.to(device)
            
            optimizer.zero_grad()
            logits = model(src, lengths)
            loss = criterion(logits, labels)
            loss.backward()
            
            # Gradient clipping para estabilidad
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            
            batch_size = src.size(0)
            total_loss += loss.item() * batch_size
            total_correct += (logits.argmax(1) == labels).sum().item()
            total_samples += batch_size
        
        train_loss = total_loss / total_samples
        train_acc = total_correct / total_samples
        
        # Fase de validación
        model.eval()
        val_correct, val_total = 0, 0
        with torch.no_grad():
            for src, lengths, labels in val_dl:
                src, labels = src.to(device), labels.to(device)
                logits = model(src, lengths)
                val_correct += (logits.argmax(1) == labels).sum().item()
                val_total += labels.size(0)
        
        val_acc = val_correct / val_total if val_total > 0 else 0.0
        
        scheduler.step()
        current_lr = scheduler.get_last_lr()[0]
        
        # Guardar mejor modelo
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            safe_torch_save(model.state_dict(), os.path.join(CONFIG['models_dir'], "best_model.pth"))
        
        # Registrar métricas de la época
        historial_epocas.append({
            'epoch': epoch,
            'train_loss': train_loss,
            'train_acc': train_acc,
            'val_acc': val_acc,
            'lr': current_lr
        })
        
        print(f"Epoch {epoch:2d}/{CONFIG['epochs']} | "
              f"Loss: {train_loss:.4f} | Train Acc: {train_acc:.3f} | "
              f"Val Acc: {val_acc:.3f} | LR: {current_lr:.2e}")
    
    # Guardar modelo final y recursos
    safe_torch_save(model.state_dict(), os.path.join(CONFIG['models_dir'], "model.pth"))
    
    # Guardar estadísticas de normalización
    stats_path = os.path.join(CONFIG['models_dir'], "normalizador_stats.json")
    try:
        stats_json = {}
        for key, value in normalizador.stats.items():
            stats_json[key] = value.tolist() if isinstance(value, np.ndarray) else value
        
        with open(stats_path, 'w', encoding='utf-8') as f:
            json.dump(stats_json, f, indent=2)
        print("✅ Estadísticas de normalización guardadas")
    except Exception as e:
        print(f"⚠️  Error guardando estadísticas: {e}")
    
    # Guardar label map
    with open(os.path.join(CONFIG['models_dir'], "label_map.json"), "w", encoding="utf-8") as f:
        json.dump(label_map, f, ensure_ascii=False, indent=2)
    
    # Actualizar métricas del sistema
    metricas.actualizar_metricas_entrenamiento(best_val_acc, historial_epocas)
    
    print(f"✅ Entrenamiento completado. Mejor val accuracy: {best_val_acc:.3f}")
    
    # Mostrar resumen de métricas
    metricas.mostrar_metricas_completas()

# =============================================================================
# FASE CRISP-DM 6: DESPLIEGUE - RECONOCIMIENTO EN TIEMPO REAL
# =============================================================================
def reconocimiento_tiempo_real():
    """Sistema de reconocimiento en tiempo real con traducción"""
    # Verificar que el modelo esté entrenado
    model_path = os.path.join(CONFIG['models_dir'], "model.pth")
    label_map_path = os.path.join(CONFIG['models_dir'], "label_map.json")
    stats_path = os.path.join(CONFIG['models_dir'], "normalizador_stats.json")
    
    if not os.path.exists(model_path) or not os.path.exists(label_map_path):
        print("❌ Entrena un modelo primero (opción 3)")
        available_classes = get_available_classes()
        if available_classes:
            print(f"💡 Tienes {len(available_classes)} clases listas: {', '.join(available_classes)}")
        return
    
    # Cargar configuraciones del modelo
    with open(label_map_path, "r", encoding="utf-8") as f:
        label_map = json.load(f)
    idx_to_word = {v: k for k, v in label_map.items()}
    
    # Cargar estadísticas de normalización
    normalizador = NormalizadorConsistente(method='zscore')
    if os.path.exists(stats_path):
        try:
            with open(stats_path, 'r', encoding='utf-8') as f:
                stats_json = json.load(f)
            
            # Reconstruir arrays numpy desde JSON
            normalizador.stats = {}
            for key, value in stats_json.items():
                normalizador.stats[key] = np.array(value) if isinstance(value, list) else value
            
            print("✅ Estadísticas de normalización cargadas")
        except Exception as e:
            print(f"⚠️  Error cargando estadísticas: {e}")
    else:
        print("⚠️  No se encontraron estadísticas de normalización")
    
    # Configurar dispositivo y modelo
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = SignLanguageTransformer(FEATURE_DIM, len(label_map)).to(device)
    
    # Cargar pesos del modelo
    model_state = safe_torch_load(model_path)
    if model_state is None:
        print("❌ No se pudo cargar el modelo entrenado")
        return
    
    model.load_state_dict(model_state)
    model.eval()
    
    # Inicializar componentes del sistema
    traductor = TraductorQuechua()
    frase_builder = FraseBuilderBilingue(traductor)
    metricas = MetricasSistema()
    
    # Inicializar cámara y detección
    cap = cv2.VideoCapture(0)
    holistic = get_holistic()
    
    # Buffers para procesamiento temporal
    buffer_frames = deque(maxlen=CONFIG['min_frames'])
    historial_predicciones = deque(maxlen=CONFIG['ventana_suavizado'])
    
    print("🚀 Reconocimiento activado. Presiona 'q' para salir, 'r' para reiniciar frase, 'd' para ver diccionario")
    print(f"📊 Modelo Transformer cargado: {len(label_map)} clases")
    print(f"🔤 Clases: {', '.join(label_map.keys())}")
    print(f"🌄 Traductor cargado: {len(DICCIONARIO_QUECHUA)} palabras")
    
    # Variables para métricas en tiempo real
    confianzas_acumuladas = []
    start_time = time.time()
    frame_count = 0
    
    # Bucle principal de reconocimiento
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        frame_count += 1
        
        # Procesar frame con MediaPipe
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = holistic.process(rgb)
        
        # Extraer características
        feats = extract_features(results)
        buffer_frames.append(feats)
        
        # Dibujar landmarks para feedback visual
        if results.pose_landmarks:
            mp_drawing.draw_landmarks(frame, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS)
        if results.left_hand_landmarks:
            mp_drawing.draw_landmarks(frame, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS)
        if results.right_hand_landmarks:
            mp_drawing.draw_landmarks(frame, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS)
        
        # Procesar reconocimiento cuando hay suficientes frames
        palabra_actual = "..."
        confianza = 0.0
        
        if len(buffer_frames) >= CONFIG['min_frames']:
            try:
                secuencia = np.array(buffer_frames)
                
                # Normalización consistente
                secuencia = normalizador.normalizar_secuencia(secuencia)
                
                # Predicción con Transformer
                src = torch.tensor(secuencia, dtype=torch.float32).unsqueeze(0).to(device)
                with torch.no_grad():
                    logits = model(src, torch.tensor([src.shape[1]]).to(device))
                    probs = torch.softmax(logits, dim=1)
                    conf, pred_idx = torch.max(probs, dim=1)
                    
                    palabra_actual = idx_to_word.get(pred_idx.item(), "...")
                    confianza = conf.item()
                    confianzas_acumuladas.append(confianza)
                
                # Suavizado temporal con ventana deslizante
                historial_predicciones.append(pred_idx.item())
                if len(historial_predicciones) >= CONFIG['ventana_suavizado'] // 2:
                    # Votación mayoritaria para estabilizar predicciones
                    counts = {}
                    for pred in historial_predicciones:
                        counts[pred] = counts.get(pred, 0) + 1
                    mejor_pred = max(counts, key=counts.get)
                    palabra_actual = idx_to_word.get(mejor_pred, "...")
                    
            except Exception as e:
                print(f"⚠️  Error en predicción: {e}")
        
        # Procesar con constructor de frases
        mensaje_estado = frase_builder.procesar_prediccion(palabra_actual, confianza)
        frase_espanol, frase_quechua = frase_builder.obtener_frase_bilingue()
        
        # Dibujar interfaz bilingüe
        dibujar_interfaz_bilingue(frame, frase_espanol, frase_quechua, palabra_actual, confianza, mensaje_estado)
        cv2.imshow("LSP - Traductor Español-Quechua Automático", frame)
        
        # Procesar comandos de usuario
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('r'):
            frase_builder.reiniciar()
            print("🔄 Frase reiniciada")
        elif key == ord('d'):
            mostrar_diccionario()
        elif key == ord('m'):  # Nuevo comando para métricas
            metricas.mostrar_metricas_completas()
    
    # Limpieza y cierre
    cap.release()
    cv2.destroyAllWindows()
    holistic.close()
    
    # Calcular métricas de la sesión
    tiempo_sesion = time.time() - start_time
    fps_promedio = frame_count / tiempo_sesion if tiempo_sesion > 0 else 0
    confianza_promedio = np.mean(confianzas_acumuladas) if confianzas_acumuladas else 0
    
    # Actualizar métricas del sistema
    frases_traducidas = 1 if frase_espanol != "[Frase vacía]" else 0
    metricas.actualizar_metricas_tiempo_real(confianza_promedio, frases_traducidas)
    
    # Mostrar resumen de la sesión
    frase_es, frase_qu = frase_builder.obtener_frase_bilingue()
    if frase_es != "[Frase vacía]":
        print(f"\n🎉 FRASE FINAL:")
        print(f"🇪🇸 Español:  '{frase_es}'")
        print(f"🌄 Quechua:   '{frase_qu}'")
    
    print(f"\n📊 Resumen de sesión:")
    print(f"   • Duración: {tiempo_sesion:.1f} segundos")
    print(f"   • FPS promedio: {fps_promedio:.1f}")
    print(f"   • Confianza promedio: {confianza_promedio:.3f}")
    print(f"   • Frames procesados: {frame_count}")

# =============================================================================
# FUNCIONES AUXILIARES DEL SISTEMA
# =============================================================================
def grabar_senia(palabra):
    """Sistema de grabación de nuevas señas para el dataset"""
    if not palabra or palabra.strip() == "":
        print("❌ La palabra no puede estar vacía")
        return
        
    palabra = palabra.strip().lower()
    
    # Verificar y traducir palabra
    traductor = TraductorQuechua()
    traduccion = traductor.traducir_palabra(palabra)
    
    if traduccion == f"[{palabra}]":
        print(f"⚠️  '{palabra}' no está en el diccionario quechua")
        respuesta = input("¿Deseas grabarla de todas formas? (s/n): ").strip().lower()
        if respuesta != 's':
            return
    else:
        print(f"✅ '{palabra}' → '{traduccion}' (en diccionario)")
    
    # Configurar directorio de grabación
    palabra_dir = os.path.join(CONFIG['dataset_dir'], palabra)
    os.makedirs(palabra_dir, exist_ok=True)
    
    sample_id = len(glob.glob(os.path.join(palabra_dir, "*.npy")))
    cap = cv2.VideoCapture(0)
    holistic = get_holistic()
    
    secuencia = []
    start_time = time.time()
    
    print(f"🎥 Grabando '{palabra}' → '{traduccion}'... Presiona 'q' para terminar")
    print("💡 Mantén la seña estable durante la grabación")
    
    # Bucle de grabación
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = holistic.process(rgb)
        
        feats = extract_features(results)
        secuencia.append(feats)
        
        # Interfaz de grabación
        cv2.putText(frame, f"Grabando: {palabra}", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(frame, f"Quechua: {traduccion}", (10, 60), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        cv2.putText(frame, f"Frames: {len(secuencia)}", (10, 90), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(frame, "Presiona 'q' para terminar", (10, 120), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        
        cv2.imshow("Grabando seña", frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
        if time.time() - start_time >= CONFIG['capture_seconds']:
            break
    
    # Finalizar grabación
    cap.release()
    cv2.destroyAllWindows()
    holistic.close()
    
    # Guardar secuencia
    if secuencia:
        secuencia = np.array(secuencia)
        output_path = os.path.join(palabra_dir, f"{sample_id:04d}.npy")
        np.save(output_path, secuencia)
        print(f"💾 Grabación guardada: {output_path} ({len(secuencia)} frames)")
        
        # Actualizar label map y métricas
        build_label_map()
        metricas = MetricasSistema()
        metricas.actualizar_metricas_dataset()
        metricas.guardar_metricas()
    else:
        print("❌ No se capturaron frames")

def listar_clases():
    """Muestra clases disponibles con información de traducción"""
    label_map = build_label_map()
    available_classes = get_available_classes()
    
    if not label_map:
        print("❌ No hay clases en el dataset")
        print("💡 Graba algunas señas primero usando la opción 1")
        return []
    
    traductor = TraductorQuechua()
    
    print("\n📚 Clases disponibles (Español → Quechua):")
    for palabra, idx in label_map.items():
        count = len(glob.glob(os.path.join(CONFIG['dataset_dir'], palabra, "*.npy")))
        traduccion = traductor.traducir_palabra(palabra)
        print(f"  {idx:2d}. {palabra} → {traduccion} ({count} muestras)")
    
    return list(label_map.keys())

def mostrar_diccionario():
    """Muestra el diccionario completo organizado por categorías"""
    print("\n📖 DICCIONARIO ESPAÑOL - QUECHUA")
    print("=" * 60)
    
    categorias = {}
    for esp, data in DICCIONARIO_QUECHUA.items():
        categoria = data["categoria"]
        if categoria not in categorias:
            categorias[categoria] = []
        categorias[categoria].append((esp, data["quechua"]))
    
    for categoria, palabras in categorias.items():
        print(f"\n🔸 {categoria.upper()}:")
        for esp, quechua in sorted(palabras):
            print(f"   {esp:15} → {quechua}")
    
    print(f"\n📊 Total: {len(DICCIONARIO_QUECHUA)} palabras en el diccionario")

def mostrar_estadisticas():
    """Muestra estadísticas básicas del dataset"""
    available_classes = get_available_classes()
    files = list_all_files()
    
    print(f"\n📊 ESTADÍSTICAS DEL DATASET:")
    print(f"Clases detectadas: {len(available_classes)}")
    print(f"Muestras totales: {len(files)}")
    print(f"Palabras en diccionario: {len(DICCIONARIO_QUECHUA)}")
    
    if available_classes:
        traductor = TraductorQuechua()
        for clase in available_classes:
            count = len(glob.glob(os.path.join(CONFIG['dataset_dir'], clase, "*.npy")))
            traduccion = traductor.traducir_palabra(clase)
            print(f"  {clase} → {traduccion}: {count} muestras")
    else:
        print("  No hay clases con muestras")

def probar_traductor_texto():
    """Sistema independiente para probar traducciones de texto"""
    traductor = TraductorQuechua()
    
    print("\n🔤 TRADUCTOR DE TEXTO ESPAÑOL→QUECHUA")
    print("Escribe 'salir' para volver al menú")
    print("=" * 50)
    
    while True:
        texto = input("\n📝 Español: ").strip()
        
        if texto.lower() == 'salir':
            break
            
        if texto:
            traduccion = traductor.traducir_frase_completa(texto)
            print(f"🌄 Quechua:  {traduccion}")
            
            # Mostrar desglose palabra por palabra
            palabras = texto.split()
            if len(palabras) > 1:
                print(f"📖 Palabra por palabra:")
                for palabra in palabras:
                    trad_palabra = traductor.traducir_palabra(palabra)
                    print(f"   {palabra} → {trad_palabra}")
        else:
            print("❌ El texto no puede estar vacío")

# =============================================================================
# MENÚ PRINCIPAL MEJORADO
# =============================================================================
def menu_principal():
    """Sistema de menú principal con todas las funcionalidades"""
    
    # Inicializar sistema de métricas
    metricas = MetricasSistema()
    
    while True:
        print("\n" + "="*70)
        print("           LSP - TRADUCTOR ESPAÑOL-QUECHUA AVANZADO")
        print("-"*70)
        print("1. 🎥 Grabar nueva seña (Fase 3: Preparación de datos)")
        print("2. 📊 Ver estadísticas del dataset (Fase 2: Comprensión de datos)") 
        print("3. 🤖 Entrenar modelo Transformer (Fase 4: Modelado)")
        print("4. 🚀 Reconocimiento en tiempo real (Fase 6: Despliegue)")
        print("5. 📝 Listar clases con traducción")
        print("6. 📖 Ver diccionario completo")
        print("7. 🔄 Probar traductor de texto")
        print("8. 📈 Ver métricas del sistema (Fase 5: Evaluación)")  # NUEVA OPCIÓN
        print("9. ❌ Salir")
        print("-"*70)
        
        opcion = input("Selecciona opción: ").strip()
        
        if opcion == '1':
            palabra = input("Ingresa la palabra en español a grabar: ").strip()
            if palabra:
                grabar_senia(palabra)
            else:
                print("❌ La palabra no puede estar vacía")
                
        elif opcion == '2':
            mostrar_estadisticas()
            
        elif opcion == '3':
            entrenar_modelo()
            
        elif opcion == '4':
            reconocimiento_tiempo_real()
            
        elif opcion == '5':
            listar_clases()
            
        elif opcion == '6':
            mostrar_diccionario()
            
        elif opcion == '7':
            probar_traductor_texto()
            
        elif opcion == '8':  # NUEVA OPCIÓN DE MÉTRICAS
            metricas.mostrar_metricas_completas()
            
        elif opcion == '9':
            print("¡Tupananchikkama! 👋 (¡Hasta pronto!)")
            break
            
        else:
            print("❌ Opción inválida")

# =============================================================================
# INICIALIZACIÓN DEL SISTEMA
# =============================================================================
if __name__ == "__main__":
    # Crear directorios necesarios
    os.makedirs(CONFIG['dataset_dir'], exist_ok=True)
    os.makedirs(CONFIG['models_dir'], exist_ok=True)
    os.makedirs(CONFIG['metrics_dir'], exist_ok=True)
    
    print("🚀 LSP - Traductor Español-Quechua Avanzado Cargado")
    print("✅ Positional Encoding implementado")
    print("✅ Atención temporal mejorada") 
    print("✅ Normalización consistente")
    print("✅ Arquitectura Transformer especializada")
    print("✅ Traductor avanzado español-quechua integrado")
    print("✅ Sistema de métricas CRISP-DM implementado")
    print(f"🌄 Diccionario expandido: {len(DICCIONARIO_QUECHUA)} palabras")
    print("✅ Funciona completamente OFFLINE")
    
    # Inicializar sistema de métricas
    metricas = MetricasSistema()
    
    # Mostrar estado inicial del sistema
    available_classes = get_available_classes()
    if available_classes:
        print(f"📊 Dataset: {len(available_classes)} clases detectadas")
    else:
        print("💡 Comienza grabando señas con la opción 1")
    
    # Iniciar menú principal
    menu_principal()
